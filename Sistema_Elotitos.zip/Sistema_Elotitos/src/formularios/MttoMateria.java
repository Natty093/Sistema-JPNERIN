/*EQUIPO 5 TALLER POO*/
package formularios;

/*Librerías*/
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MttoMateria {
    //LÍNEAS DE CÓDIGO PARA LA CONEXIÓN
    Connection cn = conectar.conectar();
    Statement st;

    private R_materia materia=new R_materia(); //Creamos una instancia de cliente
    private String SQL=""; //Variables para la consulta
    
    public DefaultTableModel mostrar(String buscar)
    {
       DefaultTableModel modelo;
       String[] titulos={"ID","Nombre","Cantidad","Precio","Fecha caducidad"};
       String[] registro=new String[5];
       modelo=new DefaultTableModel(null, titulos);
       SQL="select * from materia_prim where nom_mat_prim like '%"+buscar+"%' order by id_mat_prim";
    
    try{
        Statement st=(Statement) cn.createStatement();
        ResultSet rs=st.executeQuery(SQL);
        while((rs.next())) 
        {
            registro[0]=rs.getString("id_mat_prim");
            registro[1]=rs.getString("nom_mat_prim");
            registro[2]=rs.getString("cant_mat_prim");
            registro[3]=rs.getString("precio_mat_prim");
            registro[4]=rs.getString("caducidad_mat_prim");

            //Modelo
            modelo.addRow(registro);
        }
        
        return modelo;
        
    } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Ocurrió un error: " + e);
            return null;
        } //Cierre de catch
    
    }
    
    //método insertar
    public boolean insertar (SetyGetMateria dts)
    {
        SQL="INSERT INTO materia_prim (nom_mat_prim, cant_mat_prim,"
              + "precio_mat_prim, caducidad_mat_prim)"
              + "VALUES (?,?,?,?)";
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
                
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setString(1, dts.getNombre());
            pst.setInt(2, dts.getCantidad());
            pst.setFloat(3, dts.getPrecio());
            pst.setString(4, dts.getFecha_caducidad());
               
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
                
            //Preguntamos
            if (n>0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro guardado con éxito!");
                materia.limpiar();
                materia.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            Logger.getLogger(R_materia.class.getName()).log(Level.SEVERE, null, e);
            return false;
        } 
    }
        
    //método editar
    public boolean editar (SetyGetMateria dts)
    {
        SQL="update materia_prim set nom_mat_prim=?, cant_mat_prim=?,"
            + "precio_mat_prim=?, caducidad_mat_prim=? "
            + "where id_mat_prim=?";
        
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
            
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setString(1, dts.getNombre());
            pst.setInt(2, dts.getCantidad());
            pst.setFloat(3, dts.getPrecio());
            pst.setString(4, dts.getFecha_caducidad());
            pst.setInt(5, dts.getNumero_de_materia());
            
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
            
            //Preguntamos
            if (n!=0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro actualizado con éxito!");
                materia.limpiar();
                materia.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Error: "+e);
            return false;
        } 
    }
    
    //método eliminar
    public boolean eliminar (SetyGetMateria dts)
    {
        SQL="delete from materia_prim where id_mat_prim=?";
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
            
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setInt(1, dts.getNumero_de_materia());
            
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
            
            //Preguntamos
            if (n!=0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro eliminado con éxito!");
                //empleado.limpiar();
                //empleado.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        } 
    }
}
