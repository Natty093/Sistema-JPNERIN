/*EQUIPO 5 TALLER POO*/
package formularios;

/*Librerías*/
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MttoEmpleado {
    //LÍNEAS DE CÓDIGO PARA LA CONEXIÓN
    Connection cn = conectar.conectar();
    Statement st;

    private R_empleado empleado = new R_empleado(); //Creamos una instancia de empleado
    private String SQL=""; //Variables para la consulta
    
    public DefaultTableModel mostrar(String buscar)
    {
       DefaultTableModel modelo;
       String[] titulos={"ID","Nombre","Telefono","Correo","Contraseña"};
       String[] registro=new String[5];
       modelo=new DefaultTableModel(null, titulos);
       SQL="select * from empleado where id_emp like '%"+buscar+"%' order by id_emp";
    
    try{
        Statement st=(Statement) cn.createStatement();
        ResultSet rs=st.executeQuery(SQL);
        while((rs.next())) 
        {
            registro[0]=rs.getString("id_emp");
            registro[1]=rs.getString("nom_emp");
            registro[2]=rs.getString("telefono_emp");
            registro[3]=rs.getString("correo_emp");
            registro[4]= "******";

            //Modelo
            modelo.addRow(registro);
        }
        
        return modelo;
        
    } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Ocurrió un error: " + e);
            return null;
        } //Cierre de catch
    
    }
    
    //método insertar
    public boolean insertar (SetyGetEmpleado dts)
    {
        SQL="INSERT INTO empleado (nom_emp, telefono_emp, correo_emp,"
              + "contraseña_emp)"
              + "VALUES (?,?,?,?)";
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
                
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setString(1, dts.getNombre());
            pst.setString(2, dts.getTelefono());
            pst.setString(3, dts.getCorreo());
            pst.setString(4, dts.getContraseña());
               
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
                
            //Preguntamos
            if (n>0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro guardado con éxito!");
                empleado.limpiar();
                empleado.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            Logger.getLogger(R_empleado.class.getName()).log(Level.SEVERE, null, e);
            return false;
        } 
    }
        
    //método editar
    public boolean editar (SetyGetEmpleado dts)
    {
        SQL="update empleado set nom_emp=?, telefono_emp=?, correo_emp=?, "
            + "contraseña_emp=? "
            + "where id_emp=?";
        
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
            
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setString(1, dts.getNombre());
            pst.setString(2, dts.getTelefono());
            pst.setString(3, dts.getCorreo());
            pst.setString(4, dts.getContraseña());
            pst.setInt(5, dts.getNumero_de_empleado());
            
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
            
            //Preguntamos
            if (n!=0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro actualizado con éxito!");
                empleado.limpiar();
                empleado.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Error: "+e);
            return false;
        } 
    }
    
    //método eliminar
    public boolean eliminar (SetyGetEmpleado dts)
    {
        SQL="delete from empleado where id_emp=?";
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
            
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setInt(1, dts.getNumero_de_empleado());
            
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
            
            //Preguntamos
            if (n!=0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro eliminado con éxito!");
                //empleado.limpiar();
                //empleado.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        } 
    }
}
