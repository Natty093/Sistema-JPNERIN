/* EQUIPO 5 TALLER DE POO */
package formularios;

public class SetyGetSucursal {
    //Atributos
    private int numero_de_sucursal;
    private String nombre;
    private String direccion;
    private String CP;
    private String telefono;
    
    //Constructor
    public SetyGetSucursal(){
    }
    
    public SetyGetSucursal(int numero_de_sucursal, String nombre, String direccion, String CP, String telefono) {
        this.numero_de_sucursal = numero_de_sucursal;
        this.nombre = nombre;
        this.direccion = direccion;
        this.CP = CP;
        this.telefono = telefono;
    }
    
    //Métodos
    public int getNumero_de_sucursal() {
        return numero_de_sucursal;
    }

    public void setNumero_de_sucursal(int numero_de_sucursal) {
        this.numero_de_sucursal = numero_de_sucursal;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCP() {
        return CP;
    }

    public void setCP(String CP) {
        this.CP = CP;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    
}

