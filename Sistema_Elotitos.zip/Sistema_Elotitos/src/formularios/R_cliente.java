/* EQUIPO 5 TALLER DE POO */
package formularios;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.awt.Image;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

public class R_cliente extends javax.swing.JInternalFrame {

    public R_cliente() {
        initComponents();
        
        setResizable(false);
        setTitle("Clientes");
        bloquear();
    }
    
    //Variables
    private String accion="guardar";
    
    public void ocultar_columnas()
    {
        tablaClientes.getColumnModel().getColumn(0).setMaxWidth(30);
        tablaClientes.getColumnModel().getColumn(0).setMinWidth(20);
        tablaClientes.getColumnModel().getColumn(0).setPreferredWidth(0);
    }
    
    public void limpiar()
    {
       txtNCliente.setText("");
       txtNombre.setText("");
       txtCorreo.setText("");
       txtTelefono.setText("");
       txtDireccion.setText("");
       txtCP.setText("");
       txtRFC.setText("");
       txtCURP.setText("");
       txtFecha.setText("");
    }
    
    public void bloquear()
    {
       txtNCliente.setEnabled(false);
       txtNombre.setEnabled(false);
       txtCorreo.setEnabled(false);
       txtTelefono.setEnabled(false);
       txtDireccion.setEnabled(false);
       txtCP.setEnabled(false);
       txtRFC.setEnabled(false);
       txtCURP.setEnabled(false);
       txtFecha.setEnabled(false);
       txtBuscar.setEnabled(true);
       
       //botones
       btnNuevo.setEnabled(true);
       btnGuardar.setEnabled(false);
       btnCancelar.setEnabled(false);
       btnEliminar.setEnabled(false);
       btnBuscar.setEnabled(true);
    }
    
    public void desbloquear()
    {
       //txtNCliente.setEnabled(false);
       txtNombre.setEnabled(true);
       txtCorreo.setEnabled(true);
       txtTelefono.setEnabled(true);
       txtDireccion.setEnabled(true);
       txtCP.setEnabled(true);
       txtRFC.setEnabled(true);
       txtCURP.setEnabled(true);
       txtFecha.setEnabled(true);
       txtBuscar.setEnabled(true);
       
       //botones
       btnNuevo.setEnabled(false);
       btnGuardar.setEnabled(true);
       btnCancelar.setEnabled(true);
       btnEliminar.setEnabled(true);
       btnBuscar.setEnabled(true);
    }
    
    void mostrar(String buscar)
    { 
        try {
            DefaultTableModel modelo;
            MttoCliente func=new MttoCliente(); //Creamos la instancia
            modelo=func.mostrar(buscar);//Mandamos llamar la función
            
            tablaClientes.setModel(modelo);
            ocultar_columnas(); //mandamos llamar a este método de ocultar la columna de ID
            return;
            } catch (Exception e) {
                JOptionPane.showConfirmDialog(rootPane, e);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblNCliente = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblCorreo = new javax.swing.JLabel();
        lblTelefono = new javax.swing.JLabel();
        lblDireccion = new javax.swing.JLabel();
        lblCP = new javax.swing.JLabel();
        lblRFC = new javax.swing.JLabel();
        lblCURP = new javax.swing.JLabel();
        lblFecha = new javax.swing.JLabel();
        txtNCliente = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtCorreo = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        txtCP = new javax.swing.JTextField();
        txtRFC = new javax.swing.JTextField();
        txtCURP = new javax.swing.JTextField();
        txtFecha = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        lblBuscar = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaClientes = new javax.swing.JTable();

        setClosable(true);
        setIconifiable(true);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CLIENTES");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(654, 654, 654)
                .addComponent(jLabel1)
                .addContainerGap(709, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "REGISTRAR CLIENTE", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblNCliente.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNCliente.setText("N° CLIENTE");
        jPanel2.add(lblNCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 110, 20));

        lblNombre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNombre.setText("NOMBRE COMPLETO");
        jPanel2.add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, -1, -1));

        lblCorreo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCorreo.setText("CORREO");
        jPanel2.add(lblCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, -1, -1));

        lblTelefono.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblTelefono.setText("TELÉFONO");
        jPanel2.add(lblTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));

        lblDireccion.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblDireccion.setText("DIRECCION");
        jPanel2.add(lblDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, -1, -1));

        lblCP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCP.setText("CÓDIGO POSTAL");
        jPanel2.add(lblCP, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, -1, -1));

        lblRFC.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblRFC.setText("RFC");
        jPanel2.add(lblRFC, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, -1, -1));

        lblCURP.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCURP.setText("CURP");
        jPanel2.add(lblCURP, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, -1, -1));

        lblFecha.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblFecha.setText("FECHA");
        jPanel2.add(lblFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, -1, -1));

        txtNCliente.setEnabled(false);
        jPanel2.add(txtNCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 290, -1));
        jPanel2.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 290, -1));
        jPanel2.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 290, -1));

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        jPanel2.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 290, -1));

        txtCorreo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoActionPerformed(evt);
            }
        });
        jPanel2.add(txtCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 290, -1));

        txtTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefonoActionPerformed(evt);
            }
        });
        jPanel2.add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 160, 290, -1));

        txtDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionActionPerformed(evt);
            }
        });
        jPanel2.add(txtDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 290, -1));

        txtCP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCPActionPerformed(evt);
            }
        });
        jPanel2.add(txtCP, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 240, 290, -1));

        txtRFC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRFCActionPerformed(evt);
            }
        });
        jPanel2.add(txtRFC, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 280, 290, -1));

        txtCURP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCURPActionPerformed(evt);
            }
        });
        jPanel2.add(txtCURP, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 320, 290, -1));

        txtFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechaActionPerformed(evt);
            }
        });
        jPanel2.add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 360, 290, -1));

        btnGuardar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/guardarmodificado.png"))); // NOI18N
        btnGuardar.setText("GUARDAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        jPanel2.add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 410, 140, -1));

        btnCancelar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/eliminarmodificado.png"))); // NOI18N
        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        jPanel2.add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 410, 140, -1));

        btnNuevo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/btnAgregarmodificado.png"))); // NOI18N
        btnNuevo.setText("NUEVO");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        jPanel2.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 120, -1));

        jPanel3.setBackground(new java.awt.Color(255, 255, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "LISTADO DE CLIENTES", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblBuscar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblBuscar.setText("N° DE CLIENTE");
        jPanel3.add(lblBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, -1, -1));

        txtBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarActionPerformed(evt);
            }
        });
        jPanel3.add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 40, 140, -1));

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/btnBuscar1modificado.png"))); // NOI18N
        btnBuscar.setText("BUSCAR");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        jPanel3.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 30, -1, -1));

        btnEliminar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/btnEliminar1modificado.png"))); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel3.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 30, -1, 40));

        jScrollPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane1MouseClicked(evt);
            }
        });

        tablaClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Correo", "Telefono", "Direccion", "CP", "RFC", "CURP", "Fecha"
            }
        ));
        tablaClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaClientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaClientes);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 930, 360));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 467, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        txtNombre.transferFocus();
    }//GEN-LAST:event_txtNombreActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        //if para Nombre(s)
        if (txtNombre.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar el nombre");
            txtNombre.transferFocus();
            return;
        }
        
        //if para Correo
        if (txtCorreo.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar el correo");
            txtCorreo.transferFocus();
            return;
        }
        
        //if para Telefono
        if (txtTelefono.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar el telefono");
            txtTelefono.transferFocus();
            return;
        }

        //if para Direccion
        if (txtDireccion.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar la direccion");
            txtDireccion.transferFocus();
            return;
        }
        
        //if para CP
        if (txtCP.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar el codigo postal");
            txtCP.transferFocus();
            return;
        }
        
        //if para RFC
        if (txtRFC.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar el RFC");
            txtRFC.transferFocus();
            return;
        }

        //if para CURP
        if (txtCURP.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar la CURP");
            txtCURP.transferFocus();
            return;
        }
        
        //if para Fecha
        if (txtFecha.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar la fecha");
            txtFecha.transferFocus();
            return;
        }
        
        //Creamos instancias de las clases que vamos a ocupar
        SetyGetCliente dts=new SetyGetCliente();
        MttoCliente func=new MttoCliente();
        
        //variables 
        String varNom, varCor, varTel, varDir, varCP, varRFC, varCURP, varFec;
        
        //variable para la consulta
        String sql="";
        
        //Recibir los valores tecleados y los asignamos a las variables
        //nombre
        varNom=txtNombre.getText(); //obtenemos lo que se ingresó 
        dts.setNombre(varNom); 
        
        //correo
        varCor=txtCorreo.getText(); //obtenemos lo que se ingresó 
        dts.setCorreo(varCor);
        
        //telefono
        varTel=txtTelefono.getText(); //obtenemos lo que se ingresó 
        dts.setTelefono(varTel);
        
        //direccion
        varDir=txtDireccion.getText(); //obtenemos lo que se ingresó 
        dts.setDireccion(varDir);
        
        //CP
        varCP=txtCP.getText(); //obtenemos lo que se ingresó 
        dts.setCP(varCP); 
        
        //RFC
        varRFC=txtRFC.getText(); //obtenemos lo que se ingresó 
        dts.setRFC(varRFC);
        
        //CURP
        varCURP=txtCURP.getText(); //obtenemos lo que se ingresó 
        dts.setCURP(varCURP);
        
        //fecha
        varFec=txtFecha.getText(); //obtenemos lo que se ingresó 
        dts.setFecha(varFec);
        
        if (accion.equals("guardar"))
        {//primer if
            if(func.insertar(dts))
            {//segundo if
                JOptionPane.showMessageDialog(rootPane, "El cliente fue registrado"
                        + " satisfactoriamente");
                mostrar("");
                bloquear();
            }//segundo if
        }//primer if
        
        else if(accion.equals("editar"))
        {
            dts.setNumero_de_cliente(Integer.parseInt(txtNCliente.getText()));
            if(func.editar(dts))
            {
                JOptionPane.showMessageDialog(rootPane, "El cliente fue registrado"
                        + " satisfactoriamente");
                mostrar("");
                bloquear();
            }
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        
    }//GEN-LAST:event_txtBuscarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        mostrar(txtBuscar.getText());
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionActionPerformed
        txtDireccion.transferFocus();
    }//GEN-LAST:event_txtDireccionActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        mostrar("");
        limpiar();
        desbloquear();
        txtNombre.requestFocus();
        btnEliminar.setEnabled(false);
        btnGuardar.setText("Guardar");
        accion="guardar";
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limpiar();
        bloquear();
        btnNuevo.setEnabled(true);
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void jScrollPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane1MouseClicked

    }//GEN-LAST:event_jScrollPane1MouseClicked

    private void txtCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoActionPerformed
        txtCorreo.transferFocus();
    }//GEN-LAST:event_txtCorreoActionPerformed

    private void txtTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefonoActionPerformed
        txtTelefono.transferFocus();
    }//GEN-LAST:event_txtTelefonoActionPerformed

    private void txtCPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCPActionPerformed
        txtCP.transferFocus();
    }//GEN-LAST:event_txtCPActionPerformed

    private void txtRFCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRFCActionPerformed
        txtRFC.transferFocus();
    }//GEN-LAST:event_txtRFCActionPerformed

    private void txtCURPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCURPActionPerformed
        txtCURP.transferFocus();
    }//GEN-LAST:event_txtCURPActionPerformed

    private void txtFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaActionPerformed
        txtFecha.transferFocus();
    }//GEN-LAST:event_txtFechaActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        //Credencial
        if(!txtNCliente.getText().equals(""))
        {
            int confirmacion=JOptionPane.showConfirmDialog(rootPane, "¿Estás seguro de eliminar al cliente?", "Confirmar", 2);
            if (confirmacion==0)
            {
                SetyGetCliente dts=new SetyGetCliente();
                MttoCliente func=new MttoCliente();
                
                dts.setNumero_de_cliente(Integer.parseInt(txtNCliente.getText()));
                func.eliminar(dts);
                mostrar("");
                bloquear();
            }
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void tablaClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaClientesMouseClicked
        //Creamos instancias de las clases que vamos a ocupar
        SetyGetCliente dts=new SetyGetCliente();
        MttoCliente func=new MttoCliente();
        
        btnGuardar.setText("EDITAR");
        desbloquear();
        btnEliminar.setEnabled(true);
        accion="editar";
        
        //definimos una variable para traernos lo de tablaListado
        int fila=tablaClientes.rowAtPoint(evt.getPoint()); 
        
        //Numero de empleado
        txtNCliente.setText(tablaClientes.getValueAt(fila, 0).toString());
        
        //Nombres
        txtNombre.setText(tablaClientes.getValueAt(fila, 1).toString());
        
        //Correo
        txtCorreo.setText(tablaClientes.getValueAt(fila, 2).toString());
        
        //Telefono
        txtTelefono.setText(tablaClientes.getValueAt(fila, 3).toString());
        
        //Direccion
        txtDireccion.setText(tablaClientes.getValueAt(fila, 4).toString());
        
        //CP
        txtCP.setText(tablaClientes.getValueAt(fila, 5).toString());
        
        //RFC
        txtRFC.setText(tablaClientes.getValueAt(fila, 6).toString());
        
        //CURP
        txtCURP.setText(tablaClientes.getValueAt(fila, 7).toString());
        
        //Fecha
        txtFecha.setText(tablaClientes.getValueAt(fila, 8).toString());
    }//GEN-LAST:event_tablaClientesMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JLabel lblCP;
    private javax.swing.JLabel lblCURP;
    private javax.swing.JLabel lblCorreo;
    private javax.swing.JLabel lblDireccion;
    private javax.swing.JLabel lblFecha;
    private javax.swing.JLabel lblNCliente;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblRFC;
    private javax.swing.JLabel lblTelefono;
    private javax.swing.JTable tablaClientes;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtCP;
    private javax.swing.JTextField txtCURP;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtNCliente;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtRFC;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
