/* EQUIPO 5 TALLER DE POO */
package formularios;

public class SetyGetProveedor {
    //Atributos
    private int numero_de_proveedor;
    private String nombre;
    
    //Constructor
    public SetyGetProveedor(){
    }
    
    public SetyGetProveedor(int numero_de_proveedor, String nombre){
        this.numero_de_proveedor = numero_de_proveedor;
        this.nombre = nombre;
    }
    
    //Métodos
    public int getNumero_de_proveedor() {
        return numero_de_proveedor;
    }

    public void setNumero_de_proveedor(int numero_de_proveedor) {
        this.numero_de_proveedor = numero_de_proveedor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }   
}
