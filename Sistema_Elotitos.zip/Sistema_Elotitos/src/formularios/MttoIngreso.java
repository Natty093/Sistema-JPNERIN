/* EQUIPO 5 TALLER DE POO */
package formularios;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class MttoIngreso {

    //Iniciar sesión
    public boolean loginUser(SetyGetIngreso objeto) {
        boolean respuesta = false;

        Connection cn = conectar.conectar();
        String sql = "select id_emp, contraseña_emp from empleado where id_emp='"+objeto.getIdUsuario()+"' and contraseña_emp = '"+objeto.getPassword()+"' ";

        Statement st;
        try {
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                respuesta = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al iniciar sesión");
            JOptionPane.showMessageDialog(null, "Error al iniciar sesión");
        }
        
        return respuesta;
    }
}
