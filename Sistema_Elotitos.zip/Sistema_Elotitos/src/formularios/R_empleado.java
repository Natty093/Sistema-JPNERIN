/* EQUIPO 5 TALLER DE POO */
package formularios;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.awt.Image;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

public class R_empleado extends javax.swing.JInternalFrame {

    public R_empleado() {
        initComponents();
        
        setResizable(false);
        setTitle("Empleado");
        bloquear();
    }
    
    //Variables
    private String accion="guardar";
    
    public void ocultar_columnas()
    {
        tablaEmpleados.getColumnModel().getColumn(0).setMaxWidth(30);
        tablaEmpleados.getColumnModel().getColumn(0).setMinWidth(20);
        tablaEmpleados.getColumnModel().getColumn(0).setPreferredWidth(0);
    }
    
    public void limpiar()
    {
       txtNEmpleado.setText("");
       txtNombre.setText("");
       txtTelefono.setText("");
       txtCorreo.setText("");
       txtContra.setText("");
    }
    
    public void bloquear()
    {
       txtNEmpleado.setEnabled(false);
       txtNombre.setEnabled(false);
       txtTelefono.setEnabled(false);
       txtCorreo.setEnabled(false);
       txtContra.setEnabled(false);
       txtBuscar.setEnabled(true);
       
       //botones
       btnNuevo.setEnabled(true);
       btnGuardar.setEnabled(false);
       btnCancelar.setEnabled(false);
       btnEliminar.setEnabled(false);
       btnBuscar.setEnabled(true);
    }
    
    public void desbloquear()
    {
       //txtNCliente.setEnabled(false);
       txtNombre.setEnabled(true);
       txtTelefono.setEnabled(true);
       txtCorreo.setEnabled(true);
       txtContra.setEnabled(true);
       txtBuscar.setEnabled(true);
       
       //botones
       btnNuevo.setEnabled(false);
       btnGuardar.setEnabled(true);
       btnCancelar.setEnabled(true);
       btnEliminar.setEnabled(true);
       btnBuscar.setEnabled(true);
    }
    
    void mostrar(String buscar)
    { 
        try {
            DefaultTableModel modelo;
            MttoEmpleado func=new MttoEmpleado(); //Creamos la instancia
            modelo=func.mostrar(buscar);//Mandamos llamar la función
            
            tablaEmpleados.setModel(modelo);
            ocultar_columnas(); //mandamos llamar a este método de ocultar la columna de ID
            return;
            } catch (Exception e) {
                JOptionPane.showConfirmDialog(rootPane, e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblNEmpleado = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblTelefono = new javax.swing.JLabel();
        lblCorreo = new javax.swing.JLabel();
        lblContra = new javax.swing.JLabel();
        txtNEmpleado = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtCorreo = new javax.swing.JTextField();
        txtContra = new javax.swing.JTextField();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        lblBuscar = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaEmpleados = new javax.swing.JTable();

        setClosable(true);
        setIconifiable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("EMPLEADOS");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(493, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(487, 487, 487))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1146, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "REGISTRAR EMPLEADO", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblNEmpleado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNEmpleado.setText("N° EMPLEADO");
        jPanel2.add(lblNEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        lblNombre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNombre.setText("NOMBRE COMPLETO");
        jPanel2.add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, -1, -1));

        lblTelefono.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblTelefono.setText("TELEFONO");
        jPanel2.add(lblTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, -1, -1));

        lblCorreo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCorreo.setText("CORREO");
        jPanel2.add(lblCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));

        lblContra.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblContra.setText("CONTRASEÑA");
        jPanel2.add(lblContra, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, -1, -1));

        txtNEmpleado.setEnabled(false);
        txtNEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNEmpleadoActionPerformed(evt);
            }
        });
        jPanel2.add(txtNEmpleado, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 40, 310, -1));

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        jPanel2.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 80, 310, -1));

        txtTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefonoActionPerformed(evt);
            }
        });
        jPanel2.add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 120, 310, -1));

        txtCorreo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCorreoActionPerformed(evt);
            }
        });
        jPanel2.add(txtCorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 160, 310, -1));

        txtContra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContraActionPerformed(evt);
            }
        });
        jPanel2.add(txtContra, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 310, -1));

        btnNuevo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/btnAgregarmodificado.png"))); // NOI18N
        btnNuevo.setText("NUEVO");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        jPanel2.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, -1, -1));

        btnGuardar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/guardarmodificado.png"))); // NOI18N
        btnGuardar.setText("GUARDAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        jPanel2.add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, -1, -1));

        btnCancelar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/eliminarmodificado.png"))); // NOI18N
        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        jPanel2.add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 260, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 93, 524, 335));

        jPanel3.setBackground(new java.awt.Color(255, 255, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "LISTADO DE EMPLEADOS", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblBuscar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblBuscar.setText("N° EMPLEADO");
        jPanel3.add(lblBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, -1, -1));

        txtBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscarActionPerformed(evt);
            }
        });
        jPanel3.add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 40, 100, -1));

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/btnBuscar1modificado.png"))); // NOI18N
        btnBuscar.setText("BUSCAR");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        jPanel3.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 30, -1, -1));

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/btnEliminar1modificado.png"))); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel3.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 30, 110, 40));

        tablaEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Telefono", "Correo", "Contraseña"
            }
        ));
        tablaEmpleados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaEmpleadosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaEmpleados);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 560, 240));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(536, 93, 604, 335));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNEmpleadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNEmpleadoActionPerformed

    private void txtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscarActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        txtNombre.transferFocus();
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefonoActionPerformed
        txtTelefono.transferFocus();
    }//GEN-LAST:event_txtTelefonoActionPerformed

    private void txtCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoActionPerformed
        txtCorreo.transferFocus();
    }//GEN-LAST:event_txtCorreoActionPerformed

    private void txtContraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContraActionPerformed
        txtContra.transferFocus();
    }//GEN-LAST:event_txtContraActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        //if para Nombre(s)
        if (txtNombre.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar el nombre");
            txtNombre.transferFocus();
            return;
        }
        
        //if para Telefono
        if (txtTelefono.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar el telefono");
            txtTelefono.transferFocus();
            return;
        }
        
        //if para Correo
        if (txtCorreo.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar el correo");
            txtCorreo.transferFocus();
            return;
        }
        
        //if para Contraseña
        if (txtContra.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar la contraseña");
            txtContra.transferFocus();
            return;
        }
        
        //Creamos instancias de las clases que vamos a ocupar
        SetyGetEmpleado dts=new SetyGetEmpleado();
        MttoEmpleado func=new MttoEmpleado();
        
        //variables 
        String varNom, varTel, varCor, varCon;
        
        //variable para la consulta
        String sql="";
        
        //Recibir los valores tecleados y los asignamos a las variables
        //nombre
        varNom=txtNombre.getText(); //obtenemos lo que se ingresó 
        dts.setNombre(varNom); 
        
        //telefono
        varTel=txtTelefono.getText(); //obtenemos lo que se ingresó 
        dts.setTelefono(varTel);
        
        //correo
        varCor=txtCorreo.getText(); //obtenemos lo que se ingresó 
        dts.setCorreo(varCor);

        //contraseña
        varCon=txtContra.getText(); //obtenemos lo que se ingresó 
        dts.setContraseña(varCon);        
        
        if (accion.equals("guardar"))
        {//primer if
            if(func.insertar(dts))
            {//segundo if
                JOptionPane.showMessageDialog(rootPane, "El empleado fue registrado"
                        + " satisfactoriamente");
                mostrar("");
                bloquear();
            }//segundo if
        }//primer if
        
        else if(accion.equals("editar"))
        {
            dts.setNumero_de_empleado(Integer.parseInt(txtNEmpleado.getText()));
            if(func.editar(dts))
            {
                JOptionPane.showMessageDialog(rootPane, "El empleado fue registrado"
                        + " satisfactoriamente");
                mostrar("");
                bloquear();
            }
        }                                          
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        mostrar("");
        limpiar();
        desbloquear();
        txtNombre.requestFocus();
        btnEliminar.setEnabled(false);
        btnGuardar.setText("Guardar");
        accion="guardar";
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limpiar();
        bloquear();
        btnNuevo.setEnabled(true);
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        //Credencial
        if(!txtNEmpleado.getText().equals(""))
        {
            int confirmacion=JOptionPane.showConfirmDialog(rootPane, "¿Estás seguro de eliminar al empleado?", "Confirmar", 2);
            if (confirmacion==0)
            {
                SetyGetEmpleado dts=new SetyGetEmpleado();
                MttoEmpleado func=new MttoEmpleado();
                
                dts.setNumero_de_empleado(Integer.parseInt(txtNEmpleado.getText()));
                func.eliminar(dts);
                mostrar("");
                bloquear();
            }
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void tablaEmpleadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaEmpleadosMouseClicked
        //Creamos instancias de las clases que vamos a ocupar
        SetyGetEmpleado dts=new SetyGetEmpleado();
        MttoEmpleado func=new MttoEmpleado();
        
        btnGuardar.setText("EDITAR");
        desbloquear();
        btnEliminar.setEnabled(true);
        accion="editar";
        
        //definimos una variable para traernos lo de tablaListado
        int fila=tablaEmpleados.rowAtPoint(evt.getPoint()); 
        
        //Numero de empleado
        txtNEmpleado.setText(tablaEmpleados.getValueAt(fila, 0).toString());
        
        //Nombres
        txtNombre.setText(tablaEmpleados.getValueAt(fila, 1).toString());
        
        //Telefono
        txtTelefono.setText(tablaEmpleados.getValueAt(fila, 2).toString());
        
        //Correo
        txtCorreo.setText(tablaEmpleados.getValueAt(fila, 3).toString());
        
        //Contraseña
        txtContra.setText(tablaEmpleados.getValueAt(fila, 4).toString());
    }//GEN-LAST:event_tablaEmpleadosMouseClicked

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        mostrar(txtBuscar.getText());
    }//GEN-LAST:event_btnBuscarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JLabel lblContra;
    private javax.swing.JLabel lblCorreo;
    private javax.swing.JLabel lblNEmpleado;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblTelefono;
    private javax.swing.JTable tablaEmpleados;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtContra;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtNEmpleado;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
