/*  EQUIPO 5 TALLER DE POO */
package formularios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conectar {
    private static Connection conexion = null;
    
    public static Connection conectar() {
        try {
            if (conexion == null || conexion.isClosed()) {
                String url = "jdbc:mysql://localhost/elotitosBD?" +
                           "useSSL=false&" +  // Deshabilitar SSL
                           "autoReconnect=true&" +
                           "useUnicode=true&" +
                           "characterEncoding=UTF-8";
                conexion = DriverManager.getConnection(url, "root", "Calra.131009");
            }
            return conexion;
        } catch (SQLException e) {
            System.err.println("Error en la conexión: " + e.getMessage());
            throw new RuntimeException("Error al conectar con la BD", e);
        }
    }
    
    public static void cerrarConexion() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar conexión: " + e.getMessage());
        }
    }
}
