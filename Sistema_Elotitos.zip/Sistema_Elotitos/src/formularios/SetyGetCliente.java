/* EQUIPO 5 TALLER DE POO */
package formularios;

public class SetyGetCliente {
    //Atributos 
    private int numero_de_cliente;
    private String nombre;
    private String correo;
    private String telefono;
    private String direccion;
    private String CP;
    private String RFC;
    private String CURP;
    private String fecha;
    
    //Constructor
    public SetyGetCliente(){
    }
    
    public SetyGetCliente(int numero_de_cliente, String nombre, String correo, String telefono, String direccion, String CP, String RFC, String CURP, String fecha) {
        this.numero_de_cliente = numero_de_cliente;
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.direccion = direccion;
        this.CP = CP;
        this.RFC = RFC;
        this.CURP = CURP;
        this.fecha = fecha;
    }
    
    //Métodos
    public int getNumero_de_cliente() {
        return numero_de_cliente;
    }

    public void setNumero_de_cliente(int numero_de_cliente) {
        this.numero_de_cliente = numero_de_cliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCP() {
        return CP;
    }

    public void setCP(String CP) {
        this.CP = CP;
    }

    public String getRFC() {
        return RFC;
    }

    public void setRFC(String RFC) {
        this.RFC = RFC;
    }

    public String getCURP() {
        return CURP;
    }

    public void setCURP(String CURP) {
        this.CURP = CURP;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}
