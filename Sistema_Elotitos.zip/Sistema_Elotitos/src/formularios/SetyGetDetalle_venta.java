/*EQUIPO 5 TALLER DE POO*/
package formularios;

public class SetyGetDetalle_venta {
    //Atributos
    private int numero_de_venta;
    private float subtotal_venta;
    private float total_venta;
    private float iva_venta;
    private int numero_de_cliente;
    private int numero_de_producto;
    private String nombre_de_producto;
    private float precio_producto;
    private int cantidad_producto;
    private int idTicket;
    
    //Constructor 
    public SetyGetDetalle_venta() {
    }

    public SetyGetDetalle_venta(int numero_de_venta, float subtotal_venta, float total_venta, float iva_venta, int numero_de_cliente, int numero_de_producto, String nombre_de_producto, float precio_producto, int cantidad_producto, int idTicket) {
        this.numero_de_venta = numero_de_venta;
        this.subtotal_venta = subtotal_venta;
        this.total_venta = total_venta;
        this.iva_venta = iva_venta;
        this.numero_de_cliente = numero_de_cliente;
        this.numero_de_producto = numero_de_producto;
        this.nombre_de_producto = nombre_de_producto;
        this.precio_producto = precio_producto;
        this.cantidad_producto = cantidad_producto;
        this.idTicket = idTicket;
    }

    //Métodos
    public int getNumero_de_venta() {
        return numero_de_venta;
    }

    public void setNumero_de_venta(int numero_de_venta) {
        this.numero_de_venta = numero_de_venta;
    }

    public float getSubtotal_venta() {
        return subtotal_venta;
    }

    public void setSubtotal_venta(float subtotal_venta) {
        this.subtotal_venta = subtotal_venta;
    }

    public float getTotal_venta() {
        return total_venta;
    }

    public void setTotal_venta(float total_venta) {
        this.total_venta = total_venta;
    }

    public float getIva_venta() {
        return iva_venta;
    }

    public void setIva_venta(float iva_venta) {
        this.iva_venta = iva_venta;
    }

    public int getNumero_de_cliente() {
        return numero_de_cliente;
    }

    public void setNumero_de_cliente(int numero_de_cliente) {
        this.numero_de_cliente = numero_de_cliente;
    }

    public int getNumero_de_producto() {
        return numero_de_producto;
    }

    public void setNumero_de_producto(int numero_de_producto) {
        this.numero_de_producto = numero_de_producto;
    }

    public String getNombre_de_producto() {
        return nombre_de_producto;
    }

    public void setNombre_de_producto(String nombre_de_producto) {
        this.nombre_de_producto = nombre_de_producto;
    }

    public float getPrecio_producto() {
        return precio_producto;
    }

    public void setPrecio_producto(float precio_producto) {
        this.precio_producto = precio_producto;
    }

    public int getCantidad_producto() {
        return cantidad_producto;
    }

    public void setCantidad_producto(int cantidad_producto) {
        this.cantidad_producto = cantidad_producto;
    }

    public int getIdTicket() {
        return idTicket;
    }

    public void setIdTicket(int idTicket) {
        this.idTicket = idTicket;
    }
    
}
