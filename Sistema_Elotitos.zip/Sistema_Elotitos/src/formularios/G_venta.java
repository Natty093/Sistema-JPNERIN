/*EQUIPO 5 TALLER DE POO*/
package formularios;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.Statement;
import java.awt.Image;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import com.mysql.jdbc.PreparedStatement;

public class G_venta extends javax.swing.JInternalFrame {

    //modelo de los datos
    private DefaultTableModel modelo;

    //Lista para el detalle de venta de los productos
    ArrayList<SetyGetDetalle_venta> listaProductos = new ArrayList<>();
    private SetyGetDetalle_venta producto; //Cada producto que se cree, se agrega a la lista

    //Datos a obtener de la base
    private int numero_de_producto = 0;
    private String nombre_de_producto = "";
    private int cantidad_productoBD = 0;
    private float precio_producto = 0;

    //Esta es una excepción ya que no se encuentra este campo en la base
    private int porcentajeIva = 0;
    private String fecha;
    private int numero_de_cliente;

    private int cantidad = 0; //cantidad de productos a comprar
    private float subtotal = 0; //cantidad por precio 
    private float iva = 0;
    private float totalPagar = 0;

    //Variables para método CalcularTotalPagar
    private float subtotalGeneral = 0;
    private float ivaGeneral = 0;
    private float totalPagarGeneral = 0;
    //Fin de variables para método
    
    private int auxIdDetalle = 1;  //id_Detalleventa

    public G_venta() {
        initComponents();

        setResizable(false);
        setTitle("Venta");

        CargarClientes();
        CargarProductos();
        inicializarTabla();

        txtEfectivo.setEnabled(false);
        btnCalcular.setEnabled(false);

        txtSubtotal.setText("0.0");
        txtIVA.setText("0.0");
        txtTotal.setText("0.0");
        
        String fechaActual = "";
        Date date = new Date();
        fechaActual = new SimpleDateFormat("yyyy/MM/dd").format(date);
        
        txtFecha.setText(fechaActual);
    }

    //métododo para inicializar tabla de productos
    private void inicializarTabla() {
        modelo = new DefaultTableModel();
        modelo.addColumn("N");
        modelo.addColumn("Nombre");
        modelo.addColumn("Cantidad");
        modelo.addColumn("P. Unitario");
        modelo.addColumn("Subtotal");
        modelo.addColumn("Iva");
        modelo.addColumn("Total a pagar");
        modelo.addColumn("Acción");

        //Agregar los datos del modelo a la tabla
        this.tablaProductos.setModel(modelo);
    }

    //Método para presentar la información de la tabla Detalle_venta
    private void listaTablaProductos() {
        this.modelo.setRowCount(listaProductos.size());

        for (int i = 0; i < listaProductos.size(); i++) {
            this.modelo.setValueAt(i + 1, i, 0);
            this.modelo.setValueAt(listaProductos.get(i).getNombre_de_producto(), i, 1);
            this.modelo.setValueAt(listaProductos.get(i).getCantidad_producto(), i, 2);
            this.modelo.setValueAt(listaProductos.get(i).getPrecio_producto(), i, 3);
            this.modelo.setValueAt(listaProductos.get(i).getSubtotal_venta(), i, 4);
            this.modelo.setValueAt(listaProductos.get(i).getIva_venta(), i, 5);
            this.modelo.setValueAt(listaProductos.get(i).getTotal_venta(), i, 6);
            this.modelo.setValueAt("Eliminar", i, 7); //Botón eliminar   
        }

        //Añadir a la tabla 
        tablaProductos.setModel(modelo);
    }

    //Método para cargar clientes 
    private void CargarClientes() {
        String SQL = "SELECT nom_cli FROM cliente"; // Solo solicita la columna necesaria

        try (Connection cn = conectar.conectar(); // Se cierra automáticamente al final
                 Statement st = cn.createStatement(); ResultSet rs = st.executeQuery(SQL)) {

            jComboBoxCliente.removeAllItems();
            jComboBoxCliente.addItem("Selecciona una opción");

            while (rs.next()) {
                jComboBoxCliente.addItem(rs.getString("nom_cli"));
            }

        } catch (SQLException e) {
            System.err.println("Error al cargar clientes: " + e.getMessage());
            //Mostrar mensaje al usuario
            JOptionPane.showMessageDialog(null, "Error al cargar clientes: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //Método para cargar productos
    private void CargarProductos() {
        try (Connection cn = conectar.conectar(); Statement st = cn.createStatement(); ResultSet rs = st.executeQuery("SELECT nom_produc FROM producto")) {

            jComboBoxProducto.removeAllItems();
            jComboBoxProducto.addItem("Selecciona una opción");

            while (rs.next()) {
                jComboBoxProducto.addItem(rs.getString("nom_produc"));
            }

        } catch (SQLException e) {
            System.err.println("Error SQL: " + e.getMessage());
            JOptionPane.showMessageDialog(null,
                    "Error al cargar productos: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        } catch (RuntimeException e) {
            System.err.println("Error de conexión: " + e.getMessage());
            JOptionPane.showMessageDialog(null,
                    "No se pudo conectar a la base de datos",
                    "Error crítico",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    //Método para validar que el usuario ingrese numeros enteros
    private boolean validar(String valor) {
        try {
            int num = Integer.parseInt(valor);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    //Método para validar que el usuario ingrese numeros en calcular cambio
    private boolean validarCambio(String valor) {
        try {
            float num = Float.parseFloat(valor);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    //Método para obtener los datos del producto
    private void DatosDelProducto() {
        try {
            String SQL = "select * from producto where nom_produc = '"
                    + this.jComboBoxProducto.getSelectedItem() + "'";
            Connection cn = conectar.conectar();
            Statement st;

            st = cn.createStatement();
            ResultSet rs = st.executeQuery(SQL);

            while (rs.next()) {
                numero_de_producto = rs.getInt("id_produc");
                nombre_de_producto = rs.getString("nom_produc");
                cantidad_productoBD = rs.getInt("cant_produc");
                precio_producto = rs.getFloat("precio_produc");
                porcentajeIva = 16;

                //Para calcular iva y retornar su valor
                this.CalcularIva(precio_producto, porcentajeIva);
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener los datos del producto, " + e);
        }
    }

    //Método para calcular IVA
    private float CalcularIva(float precio, int porcentajeIva) {
        int p_iva = porcentajeIva;

        //Cálculo
        iva = (float) ((precio * cantidad) * 0.16);

        return iva;
    }

    //Método para calcular total a pagar todos los productos
    private void CalcularTotalPagar() {
        subtotalGeneral = 0;
        ivaGeneral = 0;
        totalPagarGeneral = 0;

        //Recorrer la lista de productos
        for (SetyGetDetalle_venta elemento : listaProductos) {
            subtotalGeneral += elemento.getSubtotal_venta();
            ivaGeneral += elemento.getIva_venta();
            totalPagarGeneral += elemento.getTotal_venta();
        }

        //Redondear decimales
        subtotalGeneral = (float) Math.round(subtotalGeneral * 100) / 100;
        ivaGeneral = (float) Math.round(ivaGeneral * 100) / 100;
        totalPagarGeneral = (float) Math.round(totalPagarGeneral * 100) / 100;

        //Mostrarlos en la interfaz
        txtSubtotal.setText(String.valueOf(subtotalGeneral));
        txtIVA.setText(String.valueOf(ivaGeneral));
        txtTotal.setText(String.valueOf(totalPagarGeneral));
    }

    //Método utilizado para agregar a la lista el ID del cliente
    private int obtenerIdClienteSeleccionado() {
        try {
            // Obtener el nombre del cliente seleccionado
            String nombreCliente = jComboBoxCliente.getSelectedItem().toString();

            // Consultar la BD para obtener el ID
            try (Connection cn = conectar.conectar(); PreparedStatement ps = (PreparedStatement) cn.prepareStatement(
                    "SELECT id_cliente FROM cliente WHERE nom_cli = ?")) {

                ps.setString(1, nombreCliente);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    return rs.getInt("id_cliente");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1; // Retornar -1 si hay error
    }
    
    private void RestarStockProductos(int numero_de_producto, int cantidad){
        int cantidadProductoBD = 0;
        
        try {
            Connection cn = conectar.conectar();
            String SQL = "select id_produc, cant_produc from producto where id_produc = '"+numero_de_producto+"'";
            Statement st;
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(SQL);
            
            while(rs.next()){
                cantidadProductoBD = rs.getInt("cant_produc");
            }
            
            cn.close();
        } catch (SQLException e) {
            System.out.println("Error al restar cantidad, " + e);
        }
        
        //Segundo 
        try {
            Connection cn = conectar.conectar();
            PreparedStatement consulta = (PreparedStatement) cn.prepareStatement("update producto set cant_produc=? where id_produc = '"+numero_de_producto+"'");
            int cantidadNueva = cantidadProductoBD - cantidad;
            consulta.setInt(1,cantidadNueva);
            
            if(consulta.executeUpdate()>0){
                System.out.println("Todo bien");
            } 
            
            cn.close();
            
        } catch (Exception e) {
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblCliente = new javax.swing.JLabel();
        lblProducto = new javax.swing.JLabel();
        jComboBoxCliente = new javax.swing.JComboBox<>();
        jComboBoxProducto = new javax.swing.JComboBox<>();
        txtBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        lblCantidad = new javax.swing.JLabel();
        txtCantidad = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaProductos = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        btnTicket = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        txtIVA = new javax.swing.JTextField();
        txtTotal = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btnCalcular = new javax.swing.JButton();
        txtEfectivo = new javax.swing.JTextField();
        txtCambio = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtSubtotal = new javax.swing.JTextField();

        setClosable(true);
        setIconifiable(true);
        setResizable(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("VENTA");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(338, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(301, 301, 301))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 731, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblCliente.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCliente.setText("CLIENTE");
        jPanel2.add(lblCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, -1, -1));

        lblProducto.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblProducto.setText("PRODUCTO");
        jPanel2.add(lblProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, -1, -1));

        jComboBoxCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona una opción", "Item 2", "Item 3", "Item 4" }));
        jPanel2.add(jComboBoxCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 30, -1, -1));

        jComboBoxProducto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona una opción", "Item 2", "Item 3", "Item 4" }));
        jPanel2.add(jComboBoxProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 70, -1, -1));
        jPanel2.add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 30, 92, -1));

        btnBuscar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/btnBuscar1modificado.png"))); // NOI18N
        btnBuscar.setText("BUSCAR");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        jPanel2.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, -1, -1));

        lblCantidad.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblCantidad.setText("CANTIDAD");
        jPanel2.add(lblCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, -1, -1));
        jPanel2.add(txtCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 153, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("FECHA");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(332, 87, -1, -1));
        jPanel2.add(txtFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(381, 87, 153, -1));

        btnAgregar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnAgregar.setText("AGREGAR");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        jPanel2.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 140, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 107, 719, 178));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablaProductos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaProductosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaProductos);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 679, 175));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 291, 719, 196));

        jPanel4.setBackground(new java.awt.Color(255, 255, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Opciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnTicket.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnTicket.setText("GENERAR TICKET");
        btnTicket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTicketActionPerformed(evt);
            }
        });
        jPanel4.add(btnTicket, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 499, 223, 189));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtIVA.setEnabled(false);
        jPanel5.add(txtIVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 134, -1));

        txtTotal.setEnabled(false);
        jPanel5.add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, 134, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Efectivo");
        jPanel5.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Cambio");
        jPanel5.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, -1, -1));

        btnCalcular.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnCalcular.setText("CALCULAR");
        btnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularActionPerformed(evt);
            }
        });
        jPanel5.add(btnCalcular, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 120, -1, -1));
        jPanel5.add(txtEfectivo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 134, -1));

        txtCambio.setEnabled(false);
        jPanel5.add(txtCambio, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, 134, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Subtotal");
        jPanel5.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("IVA");
        jPanel5.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Total a pagar");
        jPanel5.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 70, -1, -1));

        txtSubtotal.setEnabled(false);
        jPanel5.add(txtSubtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, 134, -1));

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 499, 490, 189));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularActionPerformed
        if (!txtEfectivo.getText().isEmpty()) {
            //Validar que se ingresen numeros
            boolean validacion = validarCambio(txtEfectivo.getText());
            if (validacion == true) {
                float efc = Float.parseFloat(txtEfectivo.getText().trim());
                float top = Float.parseFloat(txtTotal.getText().trim());

                if (efc < top) {
                    JOptionPane.showMessageDialog(null, "El dinero en efectivo no es suficiente");
                } else {
                    float cambio = (efc - top);
                    float cambi = (float) Math.round(cambio * 100) / 100;
                    String camb = String.valueOf(cambi);

                    //Presentamos el resultado obtenido 
                    txtCambio.setText(camb);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No se admiten caracteres no numéricos");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Ingrese dinero en efectivo para calcular cambio");
        }
    }//GEN-LAST:event_btnCalcularActionPerformed

    private void btnTicketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTicketActionPerformed
        //Esta parte esta distinta a la del video 
        SetyGetDetalle_venta detalle_venta = new SetyGetDetalle_venta();
        SetyGetTicket detalle_ticket = new SetyGetTicket();
        MttoVenta venta = new MttoVenta();
        
        String fechaActual = "";
        Date date = new Date();
        fechaActual = new SimpleDateFormat("yyyy/MM/dd").format(date);
        
        txtFecha.setText(fechaActual);
        
        if(!jComboBoxCliente.getSelectedItem().equals("Selecciona una opción")){
            if(listaProductos.size()>0){
                //Método para obtener el id del cliente
                numero_de_cliente = obtenerIdClienteSeleccionado();
                
                detalle_ticket.setNumero_de_ticket(0);
                detalle_ticket.setTotal_ticket(Float.parseFloat(txtTotal.getText()));
                detalle_ticket.setFecha_ticket(fechaActual);
                detalle_ticket.setNumero_de_cliente(numero_de_cliente);
                
                if(MttoVenta.guardarTicket(detalle_ticket)){
                    JOptionPane.showMessageDialog(null, "Datos para el ticket registrados");
                    
                    //Generar el ticket de venta
                    ticketPDF pdf = new ticketPDF();
                    pdf.datosCliente(numero_de_cliente);
                    pdf.generarTicketPDF();
                    
                    JOptionPane.showMessageDialog(null, "Venta registrada y PDF generado");
                    
                    int opcion = JOptionPane.showConfirmDialog(null, "¿Deseas una factura?");
                    // si = 0, no = 1, close = -1
                    switch (opcion) {
                        case 0: //presiona si 
                            //Generar la factura
                            facturaPDF pdf1 = new facturaPDF();
                            pdf1.datosCliente(numero_de_cliente);
                            pdf1.generarFacturaPDF();
                            break;
                        case 1: //presione no
                            break;
                        default: //sea que presione cancel o close 
                            break;
                    }
                    
                    //Guardar detalle de los productos comprados (Detalle_venta)
                    for(SetyGetDetalle_venta elemento : listaProductos){
                        
                        detalle_venta.setNumero_de_venta(0);
                        detalle_venta.setSubtotal_venta(elemento.getSubtotal_venta());
                        detalle_venta.setTotal_venta(elemento.getTotal_venta());
                        detalle_venta.setIva_venta(elemento.getIva_venta());
                        detalle_venta.setNumero_de_cliente(elemento.getNumero_de_cliente());
                        detalle_venta.setNumero_de_producto(elemento.getNumero_de_producto());
                        detalle_venta.setNombre_de_producto(elemento.getNombre_de_producto());
                        detalle_venta.setPrecio_producto(elemento.getPrecio_producto());
                        detalle_venta.setCantidad_producto(elemento.getCantidad_producto());
                        detalle_venta.setIdTicket(0);
                        
                        if(venta.guardar(detalle_venta)){
                            System.out.println("Detalle de venta registrado");
                            
                            txtSubtotal.setText("0.0");
                            txtIVA.setText("0.0");
                            txtTotal.setText("0.0");
                            txtEfectivo.setText("");
                            txtCambio.setText("");
                            
                            auxIdDetalle = 1;
                            
                            this.CargarClientes();
                            this.CargarProductos();
                            
                            this.RestarStockProductos(elemento.getNumero_de_producto(),elemento.getCantidad_producto());
                        } else {
                            JOptionPane.showMessageDialog(null, "Error al guardar detalle de venta");
                        }
                    }
                    
                    //Vacíamos la lista de productos
                    listaProductos.clear();
                    listaTablaProductos();
                }else{
                    JOptionPane.showMessageDialog(null, "Error al guarda datos para el ticket");
                }
            }else{
                JOptionPane.showMessageDialog(null, "Seleccione un producto");
            }
        }else{
            JOptionPane.showMessageDialog(null, "Seleccione un cliente");
        }
        
    }//GEN-LAST:event_btnTicketActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        String clienteBuscar = txtBuscar.getText().trim();
        Connection cn = conectar.conectar();
        String SQL = "select nom_cli from cliente where id_cliente = '" + clienteBuscar + "'";
        Statement st;

        try {
            st = cn.createStatement();
            ResultSet rs = st.executeQuery(SQL);

            if (rs.next()) {
                jComboBoxCliente.setSelectedItem(rs.getString("nom_cli"));
            } else {
                jComboBoxCliente.setSelectedItem("Selecciona una opción");
                JOptionPane.showMessageDialog(null, "Número incorrecto o no encontrado");
            }

            txtBuscar.setText("");
            cn.close();

        } catch (SQLException e) {
            System.out.println("Error al buscar cliente, " + e);
        }//Cierre try catch
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        String nomproducto = this.jComboBoxProducto.getSelectedItem().toString();

        //Validar que selecciones un producto
        if (nomproducto.equalsIgnoreCase("Selecciona una opción")) {
            JOptionPane.showMessageDialog(null, "Seleccione un producto");
        } else {
            // PRIMERO VALIDAR CLIENTE (NUEVO)
            String clienteSeleccionado = this.jComboBoxCliente.getSelectedItem().toString();
            if (clienteSeleccionado.equalsIgnoreCase("Selecciona una opción")) {
                JOptionPane.showMessageDialog(null, "Seleccione un cliente");
                return; // Salir del método si no hay cliente seleccionado
            }

            // Obtener el ID del cliente (asumiendo que tienes este método)
            numero_de_cliente = obtenerIdClienteSeleccionado();

            //validar que se ingrese una cantidad
            if (!txtCantidad.getText().isEmpty()) {
                //Validar que se ingresen numeros
                boolean validacion = validar(txtCantidad.getText());

                if (validacion == true) {
                    //Validar que sea mayor a 0
                    if (Integer.parseInt(txtCantidad.getText()) > 0) {
                        cantidad = Integer.parseInt(txtCantidad.getText());

                        //Ejecutar método para obtener los datos del producto
                        this.DatosDelProducto();

                        //Validar la cantidad de productos seleccionado mayor al stock en BD
                        if (cantidad <= cantidad_productoBD) {
                            subtotal = precio_producto * cantidad;
                            totalPagar = subtotal + iva;

                            //Redondeo de decimales
                            subtotal = (float) ((double) Math.round(subtotal * 100) / 100);
                            iva = (float) ((double) Math.round(iva * 100) / 100);
                            totalPagar = (float) ((double) Math.round(totalPagar * 100) / 100);

                            //Se crea un nuevo producto
                            SetyGetDetalle_venta producto = new SetyGetDetalle_venta(
                                    auxIdDetalle, //idDetalle_venta
                                    subtotal,
                                    totalPagar,
                                    iva,
                                    numero_de_cliente, // Usamos el ID obtenido
                                    numero_de_producto,
                                    nombre_de_producto,
                                    precio_producto,
                                    Integer.parseInt(txtCantidad.getText()),
                                    1/*idTicket*/);

                            //Añadir a la lista 
                            listaProductos.add(producto);

                            JOptionPane.showMessageDialog(null, "Producto agregado");
                            auxIdDetalle++;
                            txtCantidad.setText("");

                            //Volver a cargar productos
                            this.CargarProductos();
                            //Calcular el total a pagar
                            this.CalcularTotalPagar();
                            //Cálculo de efectivo
                            txtEfectivo.setEnabled(true);
                            btnCalcular.setEnabled(true);
                        } else {
                            JOptionPane.showMessageDialog(null, "La cantidad seleccionada supera el stock");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Ingresa una cantidad válida");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Debes ingresar numeros");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Ingresa la cantidad de producto");
            }
        }

        //Llamamos método para mostrar en la tabla los productos
        this.listaTablaProductos();
    }//GEN-LAST:event_btnAgregarActionPerformed

    //id de la lista
    int idArrayList = 0;
    private void tablaProductosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaProductosMouseClicked
        int fila_point = tablaProductos.rowAtPoint(evt.getPoint());
        int columna_point = 0;

        if (fila_point > -1) {
            idArrayList = (int) modelo.getValueAt(fila_point, columna_point);
        }

        int opcion = JOptionPane.showConfirmDialog(null, "¿Deseas eliminar el producto?");
        // si = 0, no = 1, close = -1
        switch (opcion) {
            case 0: //presiona si 
                listaProductos.remove(idArrayList - 1);
                this.CalcularTotalPagar();
                this.listaTablaProductos();
                break;
            case 1: //presione no
                break;
            default: //sea que presione cancel o close 
                break;
        }
    }//GEN-LAST:event_tablaProductosMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCalcular;
    private javax.swing.JButton btnTicket;
    private javax.swing.JComboBox<String> jComboBoxCliente;
    private javax.swing.JComboBox<String> jComboBoxProducto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    public static javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblCantidad;
    private javax.swing.JLabel lblCliente;
    private javax.swing.JLabel lblProducto;
    public static javax.swing.JTable tablaProductos;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtCambio;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtEfectivo;
    private javax.swing.JTextField txtFecha;
    public static javax.swing.JTextField txtIVA;
    public static javax.swing.JTextField txtSubtotal;
    public static javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
