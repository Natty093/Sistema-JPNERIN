/*EQUIPO 5 TALLER DE POO
*/
package formularios;

import static java.awt.Frame.MAXIMIZED_BOTH;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JOptionPane;

public class Principal extends javax.swing.JFrame {
    
    public Principal() {
        initComponents();
        
        setLocationRelativeTo(null);
        setResizable(false);
        setTitle("Sistema");
        this.setExtendedState(MAXIMIZED_BOTH);
    }
    
    @Override
    public Image getIconImage(){
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("img/producto icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        escritorio = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        MenuCliente = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        MenuEmpleado = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        MenuMateria = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        MenuProducto = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        MenuProveedor = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        MenuSucursal = new javax.swing.JMenuItem();
        jMenu7 = new javax.swing.JMenu();
        MenuVenta = new javax.swing.JMenuItem();
        jMenu9 = new javax.swing.JMenu();
        MenuVentas = new javax.swing.JMenuItem();
        jMenu8 = new javax.swing.JMenu();
        MenuSalir = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 204));
        setIconImage(getIconImage());

        escritorio.setBackground(new java.awt.Color(255, 255, 204));

        javax.swing.GroupLayout escritorioLayout = new javax.swing.GroupLayout(escritorio);
        escritorio.setLayout(escritorioLayout);
        escritorioLayout.setHorizontalGroup(
            escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1320, Short.MAX_VALUE)
        );
        escritorioLayout.setVerticalGroup(
            escritorioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 698, Short.MAX_VALUE)
        );

        jMenuBar1.setPreferredSize(new java.awt.Dimension(600, 50));

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/clientemodificado.png"))); // NOI18N
        jMenu1.setText("Cliente");
        jMenu1.setPreferredSize(new java.awt.Dimension(120, 0));

        MenuCliente.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        MenuCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/registrar.png"))); // NOI18N
        MenuCliente.setText("Registrar cliente");
        MenuCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuClienteActionPerformed(evt);
            }
        });
        jMenu1.add(MenuCliente);

        jMenuBar1.add(jMenu1);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/empleado icono.png"))); // NOI18N
        jMenu2.setText("Empleado");
        jMenu2.setPreferredSize(new java.awt.Dimension(130, 0));

        MenuEmpleado.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        MenuEmpleado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/registrar.png"))); // NOI18N
        MenuEmpleado.setText("Registrar empleado");
        MenuEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuEmpleadoActionPerformed(evt);
            }
        });
        jMenu2.add(MenuEmpleado);

        jMenuBar1.add(jMenu2);

        jMenu3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/materia icono.png"))); // NOI18N
        jMenu3.setText("Materia Prima");
        jMenu3.setPreferredSize(new java.awt.Dimension(150, 0));

        MenuMateria.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        MenuMateria.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/registrar.png"))); // NOI18N
        MenuMateria.setText("Registrar materia prima");
        MenuMateria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuMateriaActionPerformed(evt);
            }
        });
        jMenu3.add(MenuMateria);

        jMenuBar1.add(jMenu3);

        jMenu4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/producto icono.png"))); // NOI18N
        jMenu4.setText("Producto");
        jMenu4.setPreferredSize(new java.awt.Dimension(120, 0));

        MenuProducto.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        MenuProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/registrar.png"))); // NOI18N
        MenuProducto.setText("Registrar producto");
        MenuProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuProductoActionPerformed(evt);
            }
        });
        jMenu4.add(MenuProducto);

        jMenuBar1.add(jMenu4);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/proveedor icono.png"))); // NOI18N
        jMenu5.setText("Proveedor");
        jMenu5.setPreferredSize(new java.awt.Dimension(125, 0));

        MenuProveedor.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        MenuProveedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/registrar.png"))); // NOI18N
        MenuProveedor.setText("Registrar provedor");
        MenuProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuProveedorActionPerformed(evt);
            }
        });
        jMenu5.add(MenuProveedor);

        jMenuBar1.add(jMenu5);

        jMenu6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/sucursal icono.png"))); // NOI18N
        jMenu6.setText("Sucursal");
        jMenu6.setPreferredSize(new java.awt.Dimension(120, 0));

        MenuSucursal.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        MenuSucursal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/registrar.png"))); // NOI18N
        MenuSucursal.setText("Registrar sucursal");
        MenuSucursal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuSucursalActionPerformed(evt);
            }
        });
        jMenu6.add(MenuSucursal);

        jMenuBar1.add(jMenu6);

        jMenu7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/venta icono.png"))); // NOI18N
        jMenu7.setText("Venta");
        jMenu7.setPreferredSize(new java.awt.Dimension(100, 0));

        MenuVenta.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        MenuVenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/venta icono.png"))); // NOI18N
        MenuVenta.setText("Venta");
        MenuVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuVentaActionPerformed(evt);
            }
        });
        jMenu7.add(MenuVenta);

        jMenuBar1.add(jMenu7);

        jMenu9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/reportes icono.png"))); // NOI18N
        jMenu9.setText("Reportes");
        jMenu9.setPreferredSize(new java.awt.Dimension(120, 0));

        MenuVentas.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_J, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        MenuVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/venta icono.png"))); // NOI18N
        MenuVentas.setText("Reporte de ventas");
        MenuVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuVentasActionPerformed(evt);
            }
        });
        jMenu9.add(MenuVentas);

        jMenuBar1.add(jMenu9);

        jMenu8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icono salir.png"))); // NOI18N
        jMenu8.setText("Salir");
        jMenu8.setPreferredSize(new java.awt.Dimension(100, 0));

        MenuSalir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_K, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        MenuSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icono salir.png"))); // NOI18N
        MenuSalir.setText("Salir");
        MenuSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuSalirActionPerformed(evt);
            }
        });
        jMenu8.add(MenuSalir);

        jMenuBar1.add(jMenu8);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(escritorio)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(escritorio)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MenuVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuVentasActionPerformed
        Reportes reporte = new Reportes();
        reporte.ReportesVentas();
    }//GEN-LAST:event_MenuVentasActionPerformed

    private void MenuClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuClienteActionPerformed
        R_cliente objCliente= new R_cliente(); //Creamos un objeto 
        escritorio.add(objCliente); //Se agrega el objeto al escritorio
        objCliente.setVisible(true); //Muestra el formulario dentro del menu
    }//GEN-LAST:event_MenuClienteActionPerformed

    private void MenuEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuEmpleadoActionPerformed
        R_empleado objEmpleado= new R_empleado(); //Creamos un objeto 
        escritorio.add(objEmpleado); //Se agrega el objeto al escritorio
        objEmpleado.setVisible(true); //Muestra el formulario dentro del menu
    }//GEN-LAST:event_MenuEmpleadoActionPerformed

    private void MenuSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuSalirActionPerformed
        int resp=JOptionPane.showConfirmDialog(rootPane, "¿Estás seguro de salir?","Salir",JOptionPane.YES_NO_OPTION);
        if (resp==0)
        {
            System.exit(0);
        }
        else
        {
            
        }
    }//GEN-LAST:event_MenuSalirActionPerformed

    private void MenuMateriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuMateriaActionPerformed
        R_materia objMateria= new R_materia(); //Creamos un objeto 
        escritorio.add(objMateria); //Se agrega el objeto al escritorio
        objMateria.setVisible(true); //Muestra el formulario dentro del menu
    }//GEN-LAST:event_MenuMateriaActionPerformed

    private void MenuProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuProductoActionPerformed
        R_producto objProducto= new R_producto(); //Creamos un objeto 
        escritorio.add(objProducto); //Se agrega el objeto al escritorio
        objProducto.setVisible(true); //Muestra el formulario dentro del menu
    }//GEN-LAST:event_MenuProductoActionPerformed

    private void MenuProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuProveedorActionPerformed
        R_proveedor objProveedor= new R_proveedor(); //Creamos un objeto 
        escritorio.add(objProveedor); //Se agrega el objeto al escritorio
        objProveedor.setVisible(true); //Muestra el formulario dentro del menu
    }//GEN-LAST:event_MenuProveedorActionPerformed

    private void MenuSucursalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuSucursalActionPerformed
        R_sucursal objSucursal= new R_sucursal(); //Creamos un objeto 
        escritorio.add(objSucursal); //Se agrega el objeto al escritorio
        objSucursal.setVisible(true); //Muestra el formulario dentro del menu
    }//GEN-LAST:event_MenuSucursalActionPerformed

    private void MenuVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuVentaActionPerformed
        G_venta objVenta= new G_venta(); //Creamos un objeto 
        escritorio.add(objVenta); //Se agrega el objeto al escritorio
        objVenta.setVisible(true); //Muestra el formulario dentro del menu
    }//GEN-LAST:event_MenuVentaActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem MenuCliente;
    private javax.swing.JMenuItem MenuEmpleado;
    private javax.swing.JMenuItem MenuMateria;
    private javax.swing.JMenuItem MenuProducto;
    private javax.swing.JMenuItem MenuProveedor;
    private javax.swing.JMenuItem MenuSalir;
    private javax.swing.JMenuItem MenuSucursal;
    private javax.swing.JMenuItem MenuVenta;
    private javax.swing.JMenuItem MenuVentas;
    private javax.swing.JDesktopPane escritorio;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenu jMenu9;
    private javax.swing.JMenuBar jMenuBar1;
    // End of variables declaration//GEN-END:variables
}
