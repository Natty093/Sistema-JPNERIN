/* EQUIPO 5 TALLER DE POO */
package formularios;

public class SetyGetMateria {
    //Atributos
    private int numero_de_materia;
    private String nombre;
    private int cantidad;
    private float precio;
    private String fecha_caducidad;
    
    //Constructor 
    public SetyGetMateria(){
    }
    
    public SetyGetMateria(int numero_de_materia, String nombre, int cantidad, float precio, String fecha_caducidad){
        this.numero_de_materia = numero_de_materia;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.fecha_caducidad = fecha_caducidad;
    }
    
    //Métodos

    public int getNumero_de_materia() {
        return numero_de_materia;
    }

    public void setNumero_de_materia(int numero_de_materia) {
        this.numero_de_materia = numero_de_materia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getFecha_caducidad() {
        return fecha_caducidad;
    }

    public void setFecha_caducidad(String fecha_caducidad) {
        this.fecha_caducidad = fecha_caducidad;
    }
    
}
