/*
 * EQUIPO 5 TALLER DE POO
 */
package formularios;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.awt.Image;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

public class R_proveedor extends javax.swing.JInternalFrame {

    public R_proveedor() {
        initComponents();
        
        setResizable(false);
        setTitle("Proveedor");
        bloquear();
    }
    
    //Variables
    private String accion="guardar";
    
    public void ocultar_columnas()
    {
        tablaProveedores.getColumnModel().getColumn(0).setMaxWidth(30);
        tablaProveedores.getColumnModel().getColumn(0).setMinWidth(20);
        tablaProveedores.getColumnModel().getColumn(0).setPreferredWidth(0);
    }
    
    public void limpiar()
    {
       txtNProveedor.setText("");
       txtNombre.setText("");
    }
    
    public void bloquear()
    {
       txtNProveedor.setEnabled(false);
       txtNombre.setEnabled(false);
       txtBuscar.setEnabled(true);
       
       //botones
       btnNuevo.setEnabled(true);
       btnGuardar.setEnabled(false);
       btnCancelar.setEnabled(false);
       btnEliminar.setEnabled(false);
       btnBuscar.setEnabled(true);
    }
    
    public void desbloquear()
    {
       //txtNCliente.setEnabled(false);
       txtNombre.setEnabled(true);
       txtBuscar.setEnabled(true);
       
       //botones
       btnNuevo.setEnabled(false);
       btnGuardar.setEnabled(true);
       btnCancelar.setEnabled(true);
       btnEliminar.setEnabled(true);
       btnBuscar.setEnabled(true);
    }
    
    void mostrar(String buscar)
    { 
        try {
            DefaultTableModel modelo;
            MttoProveedor func=new MttoProveedor(); //Creamos la instancia
            modelo=func.mostrar(buscar);//Mandamos llamar la función
            
            tablaProveedores.setModel(modelo);
            ocultar_columnas(); //mandamos llamar a este método de ocultar la columna de ID
            return;
            } catch (Exception e) {
                JOptionPane.showConfirmDialog(rootPane, e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lblNProveedor = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        txtNProveedor = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        lblBuscar = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaProveedores = new javax.swing.JTable();

        setClosable(true);
        setIconifiable(true);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("PROVEEDORES");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(398, 398, 398)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "REGISTRAR PROVEEDOR", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblNProveedor.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNProveedor.setText("ID");
        jPanel2.add(lblNProveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 50, -1, -1));

        lblNombre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNombre.setText("NOMBRE");
        jPanel2.add(lblNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 100, -1, -1));

        txtNProveedor.setEnabled(false);
        jPanel2.add(txtNProveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 190, -1));

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        jPanel2.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 190, -1));

        btnNuevo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/btnAgregarmodificado.png"))); // NOI18N
        btnNuevo.setText("NUEVO");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        jPanel2.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        btnGuardar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/guardarmodificado.png"))); // NOI18N
        btnGuardar.setText("GUARDAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        jPanel2.add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 150, -1, -1));

        btnCancelar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/eliminarmodificado.png"))); // NOI18N
        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });
        jPanel2.add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 150, -1, -1));

        jPanel3.setBackground(new java.awt.Color(255, 255, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "LISTADO DE PROVEEDORES", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblBuscar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblBuscar.setText("NOMBRE");
        jPanel3.add(lblBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, -1, -1));
        jPanel3.add(txtBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, 120, -1));

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/btnBuscar1modificado.png"))); // NOI18N
        btnBuscar.setText("BUSCAR");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        jPanel3.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 30, -1, -1));

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/btnEliminar1modificado.png"))); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        jPanel3.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 30, -1, 40));

        tablaProveedores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "ID", "Nombre"
            }
        ));
        tablaProveedores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaProveedoresMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaProveedores);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 530, 130));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 561, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        //if para Nombre
        if (txtNombre.getText().length()==0)
        {
            JOptionPane.showConfirmDialog(rootPane, "Debes ingresar el nombre");
            txtNombre.transferFocus();
            return;
        }
        
        //Creamos instancias de las clases que vamos a ocupar
        SetyGetProveedor dts=new SetyGetProveedor();
        MttoProveedor func=new MttoProveedor();
        
        //variables 
        String varNom;
        
        //variable para la consulta
        String sql="";
        
        //Recibir los valores tecleados y los asignamos a las variables
        //nombre
        varNom=txtNombre.getText(); //obtenemos lo que se ingresó 
        dts.setNombre(varNom); 
        
        if (accion.equals("guardar"))
        {//primer if
            if(func.insertar(dts))
            {//segundo if
                JOptionPane.showMessageDialog(rootPane, "El proveedor fue registrado"
                        + " satisfactoriamente");
                mostrar("");
                bloquear();
            }//segundo if
        }//primer if
        
        else if(accion.equals("editar"))
        {
            dts.setNumero_de_proveedor(Integer.parseInt(txtNProveedor.getText()));
            if(func.editar(dts))
            {
                JOptionPane.showMessageDialog(rootPane, "El proveedor fue registrado"
                        + " satisfactoriamente");
                mostrar("");
                bloquear();
            }
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        mostrar(txtBuscar.getText());
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        mostrar("");
        limpiar();
        desbloquear();
        txtNombre.requestFocus();
        btnEliminar.setEnabled(false);
        btnGuardar.setText("Guardar");
        accion="guardar";
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limpiar();
        bloquear();
        btnNuevo.setEnabled(true);
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        //Credencial
        if(!txtNProveedor.getText().equals(""))
        {
            int confirmacion=JOptionPane.showConfirmDialog(rootPane, "¿Estás seguro de eliminar el proveedor?", "Confirmar", 2);
            if (confirmacion==0)
            {
                SetyGetProveedor dts=new SetyGetProveedor();
                MttoProveedor func=new MttoProveedor();
                
                dts.setNumero_de_proveedor(Integer.parseInt(txtNProveedor.getText()));
                func.eliminar(dts);
                mostrar("");
                bloquear();
            }
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void tablaProveedoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaProveedoresMouseClicked
        //Creamos instancias de las clases que vamos a ocupar
        SetyGetProveedor dts=new SetyGetProveedor();
        MttoProveedor func=new MttoProveedor();
        
        btnGuardar.setText("EDITAR");
        desbloquear();
        btnEliminar.setEnabled(true);
        accion="editar";
        
        //definimos una variable para traernos lo de tablaListado
        int fila=tablaProveedores.rowAtPoint(evt.getPoint()); 
        
        //Numero de empleado
        txtNProveedor.setText(tablaProveedores.getValueAt(fila, 0).toString());
        
        //Nombre
        txtNombre.setText(tablaProveedores.getValueAt(fila, 1).toString());
    }//GEN-LAST:event_tablaProveedoresMouseClicked

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        txtNombre.transferFocus();
    }//GEN-LAST:event_txtNombreActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JLabel lblNProveedor;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JTable tablaProveedores;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtNProveedor;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
