/* EQUIPO 5 TALLER DE POO */
package formularios;

public class SetyGetIngreso {
    //Atributos
    private int idUsuario;
    private String password;
    
    //Constructor
    public SetyGetIngreso(){
        this.idUsuario = 0;
        this.password = "";
    }
    
    //Set and Get
    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }  
}
