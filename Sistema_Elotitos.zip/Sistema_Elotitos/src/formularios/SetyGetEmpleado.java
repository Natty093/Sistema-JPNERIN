/* EQUIPO 5 TALLER DE POO */

package formularios;

public class SetyGetEmpleado {
    //Atributos
    private int numero_de_empleado;
    private String nombre;
    private String telefono;
    private String correo;
    private String contraseña;
    
    //Constructor
    public SetyGetEmpleado(){
    }
    
    public SetyGetEmpleado(int numero_de_empleado, String nombre, String telefono, String correo, String contraseña){
        this.numero_de_empleado = numero_de_empleado;
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
        this.contraseña = contraseña;
    }
    
    //Métodos
    public int getNumero_de_empleado() {
        return numero_de_empleado;
    }

    public void setNumero_de_empleado(int numero_de_empleado) {
        this.numero_de_empleado = numero_de_empleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
}
