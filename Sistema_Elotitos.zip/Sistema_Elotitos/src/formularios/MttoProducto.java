/*EQUIPO 5 TALLER POO*/
package formularios;

/*Librerías*/
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MttoProducto {
    //LÍNEAS DE CÓDIGO PARA LA CONEXIÓN
    Connection cn = conectar.conectar();
    Statement st;

    private R_producto producto = new R_producto(); //Creamos una instancia de cliente
    private String SQL=""; //Variables para la consulta
    
    public DefaultTableModel mostrar(String buscar)
    {
       DefaultTableModel modelo;
       String[] titulos={"ID", "Nombre","Precio","Cantidad"};
       String[] registro=new String[4];
       modelo=new DefaultTableModel(null, titulos);
       SQL="select * from producto where nom_produc like '%"+buscar+"%' order by id_produc";
    
    try{
        Statement st=(Statement) cn.createStatement();
        ResultSet rs=st.executeQuery(SQL);
        while((rs.next())) 
        {
            registro[0]=rs.getString("id_produc");
            registro[1]=rs.getString("nom_produc");
            registro[2]=rs.getString("precio_produc");
            registro[3]=rs.getString("cant_produc");

            //Modelo
            modelo.addRow(registro);
        }
        
        return modelo;
        
    } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Ocurrió un error: " + e);
            return null;
        } //Cierre de catch
    
    }
    
    //método insertar
    public boolean insertar (SetyGetProducto dts)
    {
        SQL="INSERT INTO producto (nom_produc, precio_produc,"
              + "cant_produc)"
              + "VALUES (?,?,?)";
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
                
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setString(1, dts.getNombre());
            pst.setFloat(2, dts.getPrecio());
            pst.setInt(3, dts.getCantidad());
               
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
                
            //Preguntamos
            if (n>0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro guardado con éxito!");
                producto.limpiar();
                producto.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            Logger.getLogger(R_producto.class.getName()).log(Level.SEVERE, null, e);
            return false;
        } 
    }
        
    //método editar
    public boolean editar (SetyGetProducto dts)
    {
        SQL="update producto set nom_produc=?, precio_produc=?,"
            + "cant_produc=? "
            + "where id_produc=?";
        
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
            
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setString(1, dts.getNombre());
            pst.setFloat(2, dts.getPrecio());
            pst.setInt(3, dts.getCantidad());
            pst.setInt(4, dts.getNumero_de_producto());
            
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
            
            //Preguntamos
            if (n!=0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro actualizado con éxito!");
                producto.limpiar();
                producto.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Error: "+e);
            return false;
        } 
    }
    
    //método eliminar
    public boolean eliminar (SetyGetProducto dts)
    {
        SQL="delete from producto where id_produc=?";
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
            
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setInt(1, dts.getNumero_de_producto());
            
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
            
            //Preguntamos
            if (n!=0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro eliminado con éxito!");
                //empleado.limpiar();
                //empleado.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        } 
    }
}
