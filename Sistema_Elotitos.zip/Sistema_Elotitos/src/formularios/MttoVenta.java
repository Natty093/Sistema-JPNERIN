/* EQUIPO 5 TALLER POO */
package formularios;

import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class MttoVenta {
    public static int idTicketGenerado; // Variable para almacenar el ID del ticket
    
    public static boolean guardarTicket(SetyGetTicket objeto) {
        Connection cn = conectar.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement(
                "INSERT INTO ticket VALUES (?,?,?,?)", 
                Statement.RETURN_GENERATED_KEYS);
            
            consulta.setInt(1, 0);
            consulta.setFloat(2, objeto.getTotal_ticket());
            consulta.setString(3, objeto.getFecha_ticket());
            consulta.setInt(4, objeto.getNumero_de_cliente());
            
            if(consulta.executeUpdate() > 0) {
                ResultSet rs = consulta.getGeneratedKeys();
                if(rs.next()) {
                    idTicketGenerado = rs.getInt(1); // Almacena el ID generado
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error al guardar ticket: " + e.getMessage());
        }
        return false;
    }
    
    public static boolean guardar(SetyGetDetalle_venta objeto) {
        Connection cn = conectar.conectar();
        try {
            PreparedStatement consulta = cn.prepareStatement(
                "INSERT INTO detalle_venta VALUES (?,?,?,?,?,?,?,?,?,?)");
            
            consulta.setInt(1, 0);
            consulta.setFloat(2, objeto.getSubtotal_venta());
            consulta.setFloat(3, objeto.getTotal_venta());
            consulta.setFloat(4, objeto.getIva_venta());
            consulta.setInt(5, objeto.getNumero_de_cliente());
            consulta.setInt(6, objeto.getNumero_de_producto());
            consulta.setString(7, objeto.getNombre_de_producto());
            consulta.setFloat(8, objeto.getPrecio_producto());
            consulta.setInt(9, objeto.getCantidad_producto());
            consulta.setInt(10, idTicketGenerado); // Usa el ID almacenado
            
            return consulta.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al guardar detalle: " + e.getMessage());
        }
        return false;
    }
}
