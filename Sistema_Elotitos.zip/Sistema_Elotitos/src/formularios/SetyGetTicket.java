/* EQUIPO 5 TALLER DE POO */
package formularios;

public class SetyGetTicket {
    //Atributos o variables
    private int numero_de_ticket;
    private float total_ticket;
    private String fecha_ticket;
    private int numero_de_cliente;
    
    //Constructor
    public SetyGetTicket() {
    }
    
    public SetyGetTicket(int numero_de_ticket, float total_ticket, String fecha_ticket, int numero_de_cliente, int numero_de_producto, String nombre_de_producto, float precio_producto, int numero_de_empleado) {
        this.numero_de_ticket = numero_de_ticket;
        this.total_ticket = total_ticket;
        this.fecha_ticket = fecha_ticket;
        this.numero_de_cliente = numero_de_cliente;
    }
    
    //Métodos 
    public int getNumero_de_ticket() {
        return numero_de_ticket;
    }

    public void setNumero_de_ticket(int numero_de_ticket) {
        this.numero_de_ticket = numero_de_ticket;
    }

    public float getTotal_ticket() {
        return total_ticket;
    }

    public void setTotal_ticket(float total_ticket) {
        this.total_ticket = total_ticket;
    }

    public String getFecha_ticket() {
        return fecha_ticket;
    }

    public void setFecha_ticket(String fecha_ticket) {
        this.fecha_ticket = fecha_ticket;
    }

    public int getNumero_de_cliente() {
        return numero_de_cliente;
    }

    public void setNumero_de_cliente(int numero_de_cliente) {
        this.numero_de_cliente = numero_de_cliente;
    }   
}
