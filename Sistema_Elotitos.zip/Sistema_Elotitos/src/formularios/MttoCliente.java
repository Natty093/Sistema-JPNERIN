/*EQUIPO 5 TALLER POO*/
package formularios;

/*Librerías*/
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MttoCliente {
    //LÍNEAS DE CÓDIGO PARA LA CONEXIÓN
    Connection cn = conectar.conectar();
    Statement st;

    private R_cliente cliente=new R_cliente(); //Creamos una instancia de cliente
    private String SQL=""; //Variables para la consulta
    
    public DefaultTableModel mostrar(String buscar)
    {
       DefaultTableModel modelo;
       String[] titulos={"ID","Nombre","Correo","Telefono","Direccion","CP",
                        "RFC", "CURP", "Fecha"};
       String[] registro=new String[9];
       modelo=new DefaultTableModel(null, titulos);
       SQL="select * from cliente where id_cliente like '%"+buscar+"%' order by id_cliente";
    
    try{
        Statement st=(Statement) cn.createStatement();
        ResultSet rs=st.executeQuery(SQL);
        while((rs.next())) 
        {
            registro[0]=rs.getString("id_cliente");
            registro[1]=rs.getString("nom_cli");
            registro[2]=rs.getString("correo_cli");
            registro[3]=rs.getString("telefono_cli");
            registro[4]=rs.getString("direccion_cli");
            registro[5]=rs.getString("cp_cli");
            registro[6]=rs.getString("rfc_cli");
            registro[7]=rs.getString("curp");
            registro[8]=rs.getString("fecha_registro");

            //Modelo
            modelo.addRow(registro);
        }
        
        return modelo;
        
    } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Ocurrió un error: " + e);
            return null;
        } //Cierre de catch
    
    }
    
    //método insertar
    public boolean insertar (SetyGetCliente dts)
    {
        SQL="INSERT INTO cliente (nom_cli, correo_cli, telefono_cli, "
              + "direccion_cli, cp_cli, rfc_cli, curp, fecha_registro)"
              + "VALUES (?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
                
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setString(1, dts.getNombre());
            pst.setString(2, dts.getCorreo());
            pst.setString(3, dts.getTelefono());
            pst.setString(4, dts.getDireccion());
            pst.setString(5, dts.getCP());
            pst.setString(6, dts.getRFC());
            pst.setString(7, dts.getCURP());
            pst.setString(8, dts.getFecha());
               
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
                
            //Preguntamos
            if (n>0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro guardado con éxito!");
                cliente.limpiar();
                cliente.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            Logger.getLogger(R_cliente.class.getName()).log(Level.SEVERE, null, e);
            return false;
        } 
    }
        
    //método editar
    public boolean editar (SetyGetCliente dts)
    {
        SQL="update cliente set nom_cli=?, correo_cli=?, telefono_cli=?, "
            + "direccion_cli=?, cp_cli=?, rfc_cli=?, curp=?, fecha_registro=? "
            + "where id_cliente=?";
        
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
            
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setString(1, dts.getNombre());
            pst.setString(2, dts.getCorreo());
            pst.setString(3, dts.getTelefono());
            pst.setString(4, dts.getDireccion());
            pst.setString(5, dts.getCP());
            pst.setString(6, dts.getRFC());
            pst.setString(7, dts.getCURP());
            pst.setString(8, dts.getFecha());
            pst.setInt(9, dts.getNumero_de_cliente());
            
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
            
            //Preguntamos
            if (n!=0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro actualizado con éxito!");
                cliente.limpiar();
                cliente.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Error: "+e);
            return false;
        } 
    }
    
    //método eliminar
    public boolean eliminar (SetyGetCliente dts)
    {
        SQL="delete from cliente where id_cliente=?";
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
            
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setInt(1, dts.getNumero_de_cliente());
            
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
            
            //Preguntamos
            if (n!=0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro eliminado con éxito!");
                //empleado.limpiar();
                //empleado.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        } 
    }
}
