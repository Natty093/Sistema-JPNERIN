/* EQUIPO 5 TALLER DE POO */

package formularios;

public class SetyGetProducto {
    //Atributos
    private int numero_de_producto;
    private String nombre;
    private float precio;
    private int cantidad;
    
    //Constructor
    public SetyGetProducto(){
    }
    
    public SetyGetProducto(int numero_de_producto, String nombre, float precio, int cantidad){
        this.numero_de_producto = numero_de_producto;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }
    
    //Métodos
    public int getNumero_de_producto() {
        return numero_de_producto;
    }

    public void setNumero_de_producto(int numero_de_producto) {
        this.numero_de_producto = numero_de_producto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
}
