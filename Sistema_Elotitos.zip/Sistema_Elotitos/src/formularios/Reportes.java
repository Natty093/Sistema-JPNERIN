/* EQUIPO 5 TALLER DE POO */
package formularios;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Reportes {

    //Crear reportes de las ventas registrados en el sistema
    public void ReportesVentas() {
        Document documento = new Document();
        try {
            String rutaDescargas = System.getProperty("user.home") + "\\Downloads";
            String nombreArchivo = "Reporte_Venta.pdf";
            String rutaCompleta = rutaDescargas + "\\" + nombreArchivo;
            
            
            // Crear PDF
            PdfWriter.getInstance(documento, new FileOutputStream(rutaCompleta));

            // Configurar imagen
            Image header = Image.getInstance("src/img/header1.jpg");
            header.scaleToFit(650, 1000);
            header.setAlignment(Chunk.ALIGN_CENTER);

            //Formato al texto 
            Paragraph parrafo = new Paragraph();
            parrafo.setAlignment(Paragraph.ALIGN_CENTER);
            parrafo.add("Reporte creado por \nElotitos de el Carmen N.L.\n\n");
            parrafo.setFont(FontFactory.getFont("Tahoma", 18, Font.BOLD, BaseColor.DARK_GRAY));
            parrafo.add("Reporte de ventas \n\n");

            documento.open();
            //Agregamos los datos
            documento.add(header);
            documento.add(parrafo);
            
            float[] columnsWidths = {3, 9, 4, 5};

            PdfPTable tabla = new PdfPTable(columnsWidths);
            tabla.addCell("Código");
            tabla.addCell("Cliente");
            tabla.addCell("Total Pagar");
            tabla.addCell("Fecha Venta");

            try {
                Connection cn = conectar.conectar();
                PreparedStatement pst = cn.prepareStatement(
                        "select t.id_ticket, c.nom_cli, t.total_ticket, t.fecha_ticket " 
                        +"from ticket as t, cliente as c " 
                        + "where  t.id_cli = c.id_cliente");
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    do {
                        tabla.addCell(rs.getString(1));
                        tabla.addCell(rs.getString(2));
                        tabla.addCell(rs.getString(3));
                        tabla.addCell(rs.getString(4));
                    } while (rs.next());
                    documento.add(tabla);
                }
            } catch (Exception e) {
                System.out.println("Error en: " + e);
            }//try catch
            
            documento.close();
            
            JOptionPane.showMessageDialog(null, "Reporte creado. Guardado en descargas");

        } catch (DocumentException e) {
            System.out.println("Error 1 en : " + e);
        } catch (FileNotFoundException ex) {
            System.out.println("Error 2 en: "+ ex);
        } catch (IOException ex) {
            System.out.println("Error 3 en: "+ ex);
        }//try catch

    }

}
