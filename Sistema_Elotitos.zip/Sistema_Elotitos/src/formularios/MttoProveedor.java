/*EQUIPO 5 TALLER POO*/
package formularios;

/*Librerías*/
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MttoProveedor {
    //LÍNEAS DE CÓDIGO PARA LA CONEXIÓN
    Connection cn = conectar.conectar();
    Statement st;

    private R_proveedor proveedor=new R_proveedor(); //Creamos una instancia de cliente
    private String SQL=""; //Variables para la consulta
    
    public DefaultTableModel mostrar(String buscar)
    {
       DefaultTableModel modelo;
       String[] titulos={"ID","Nombre"};
       String[] registro=new String[2];
       modelo=new DefaultTableModel(null, titulos);
       SQL="select * from proveedor where nom_prove like '%"+buscar+"%' order by id_prove";
    
    try{
        Statement st=(Statement) cn.createStatement();
        ResultSet rs=st.executeQuery(SQL);
        while((rs.next())) 
        {
            registro[0]=rs.getString("id_prove");
            registro[1]=rs.getString("nom_prove");

            //Modelo
            modelo.addRow(registro);
        }
        
        return modelo;
        
    } catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Ocurrió un error: " + e);
            return null;
        } //Cierre de catch
    
    }
    
    //método insertar
    public boolean insertar (SetyGetProveedor dts)
    {
        SQL="INSERT INTO proveedor (nom_prove)"
              + "VALUES (?)";
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
                
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setString(1, dts.getNombre());
               
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
                
            //Preguntamos
            if (n>0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro guardado con éxito!");
                proveedor.limpiar();
                proveedor.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            Logger.getLogger(R_proveedor.class.getName()).log(Level.SEVERE, null, e);
            return false;
        } 
    }
        
    //método editar
    public boolean editar (SetyGetProveedor dts)
    {
        SQL="update proveedor set nom_prove=?"
            + "where id_prove=?";
        
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
            
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setString(1, dts.getNombre());
            pst.setInt(2, dts.getNumero_de_proveedor());
            
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
            
            //Preguntamos
            if (n!=0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro actualizado con éxito!");
                proveedor.limpiar();
                proveedor.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, "Error: "+e);
            return false;
        } 
    }
    
    //método eliminar
    public boolean eliminar (SetyGetProveedor dts)
    {
        SQL="delete from proveedor where id_prove=?";
        try {
            PreparedStatement pst=cn.prepareStatement(SQL);
            
            //Usamos los GETTER y SETTER que habíamos creado
            pst.setInt(1, dts.getNumero_de_proveedor());
            
            //Definimos una variable para mostrar
            int n=pst.executeUpdate();
            
            //Preguntamos
            if (n!=0)
            { //Inicia if
                JOptionPane.showMessageDialog(null, "¡Registro eliminado con éxito!");
                //empleado.limpiar();
                //empleado.bloquear();
                return true;
            } //Termina if
            return false;
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(null, e);
            return false;
        } 
    }
}
